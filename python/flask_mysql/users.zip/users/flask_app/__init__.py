from flask import Flask, redirect, render_template,request
# import the class from friend.py


app = Flask(__name__)