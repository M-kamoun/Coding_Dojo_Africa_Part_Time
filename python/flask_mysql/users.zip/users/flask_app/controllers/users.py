from flask_app import app
from flask import redirect, render_template,request
from flask_app.models.user import User



@app.route('/')
def index():
    return redirect('/users')

@app.route('/users')
def read():
    users = User.get_all()
    print(users)
    return render_template('read.html',users=users)


@app.route('/create_user',methods=["POST"])
def create_user():
    User.save(request.form)
    return redirect('/')

@app.route('/user/new')
def new():
    return render_template('create.html')







