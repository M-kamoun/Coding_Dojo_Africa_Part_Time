package com.app.travels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaveTravelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
