package com.app.hoppers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoppersApplicationTests {

	@Test
	void contextLoads() {
	}

}
